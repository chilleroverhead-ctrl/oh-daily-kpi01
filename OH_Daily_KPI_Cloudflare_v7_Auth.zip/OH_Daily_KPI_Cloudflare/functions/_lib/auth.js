const SESSION_COOKIE = 'ohkpi_session';
const SESSION_DAYS = 7;
const enc = new TextEncoder();
export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers } });
}
export async function sha256(value) {
  const digest = await crypto.subtle.digest('SHA-256', enc.encode(value));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, '0')).join('');
}
export function randomToken(bytes = 32) {
  const data = crypto.getRandomValues(new Uint8Array(bytes));
  return btoa(String.fromCharCode(...data)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
export async function hashPassword(password, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 100000, hash: 'SHA-256' }, key, 256);
  return [...new Uint8Array(bits)].map(x => x.toString(16).padStart(2, '0')).join('');
}
export function cookieHeader(token, maxAge = SESSION_DAYS * 86400) {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}
export function clearCookieHeader() { return cookieHeader('', 0); }
export async function currentUser(request, env) {
  const cookie = request.headers.get('Cookie') || '';
  const match = cookie.match(/(?:^|;\s*)ohkpi_session=([^;]+)/);
  if (!match) return null;
  const tokenHash = await sha256(decodeURIComponent(match[1]));
  const row = await env.DB.prepare(`SELECT u.id, u.email, u.role, u.verified, u.active
    FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at > datetime('now') AND u.active=1 AND u.verified=1`).bind(tokenHash).first();
  return row || null;
}
export async function requireUser(request, env, roles = null) {
  const user = await currentUser(request, env);
  if (!user) return { error: json({ error: 'กรุณาเข้าสู่ระบบใหม่' }, 401) };
  if (roles && !roles.includes(user.role)) return { error: json({ error: 'บัญชีนี้ไม่มีสิทธิ์ดำเนินการ' }, 403) };
  return { user };
}
export function allowedDomains(env) {
  return String(env.COMPANY_EMAIL_DOMAINS || '').split(',').map(x => x.trim().toLowerCase().replace(/^@/, '')).filter(Boolean);
}
export function validCompanyEmail(email, env) {
  const at = email.lastIndexOf('@');
  if (at < 1) return false;
  const domain = email.slice(at + 1).toLowerCase();
  const domains = allowedDomains(env);
  return domains.length > 0 && domains.includes(domain);
}
export async function sendVerificationEmail(env, email, token, origin) {
  if (!env.RESEND_API_KEY || !env.RESEND_FROM) throw new Error('ระบบยืนยันอีเมลยังไม่ได้ตั้งค่า RESEND_API_KEY และ RESEND_FROM');
  const url = `${origin}/?verify=${encodeURIComponent(token)}`;
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { 'Authorization': `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: env.RESEND_FROM, to: [email], subject: 'ยืนยันอีเมลสำหรับ OH Daily KPI', html: `<div style="font-family:Arial,sans-serif;line-height:1.6"><h2>ยืนยันอีเมล OH Daily KPI</h2><p>กดปุ่มด้านล่างเพื่อยืนยันอีเมลและเปิดใช้งานบัญชีของคุณ ลิงก์มีอายุ 30 นาที</p><p><a href="${url}" style="display:inline-block;padding:12px 18px;background:#1676b8;color:white;text-decoration:none;border-radius:6px">ยืนยันอีเมล</a></p><p>หากคุณไม่ได้สมัครใช้งาน สามารถละเว้นอีเมลนี้ได้</p></div>` })
  });
  if (!response.ok) throw new Error(`ส่งอีเมลยืนยันไม่สำเร็จ (${response.status})`);
}
