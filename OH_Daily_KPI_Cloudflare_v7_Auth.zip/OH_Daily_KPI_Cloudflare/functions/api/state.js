import { json, requireUser } from '../_lib/auth.js';
const etagFor = row => row?.updated_at ? `"${row.updated_at}"` : null;
export async function onRequestGet({ request, env }) {
  const auth = await requireUser(request, env); if (auth.error) return auth.error;
  try {
    const row = await env.DB.prepare('SELECT state_json, updated_at FROM app_state WHERE id = 1').first();
    if (!row) return json(null);
    return new Response(row.state_json, { headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'ETag': etagFor(row) } });
  } catch (error) { return json({ error: 'อ่านฐานข้อมูลไม่ได้' }, 500); }
}
export async function onRequestPost({ request, env }) {
  const auth = await requireUser(request, env, ['Admin','Editor']); if (auth.error) return auth.error;
  try {
    const data = await request.json();
    if (!data || !Array.isArray(data.metrics) || data.metrics.length > 500) return json({ error: 'รูปแบบข้อมูลไม่ถูกต้อง' }, 400);
    const jsonText = JSON.stringify(data);
    if (jsonText.length > 2_000_000) return json({ error: 'ข้อมูลมีขนาดใหญ่เกินไป' }, 413);
    const current = await env.DB.prepare('SELECT updated_at FROM app_state WHERE id=1').first();
    const ifMatch = request.headers.get('If-Match');
    if (current && ifMatch !== etagFor(current)) return json({ error: 'มีผู้ใช้อื่นบันทึกข้อมูลหลังจากคุณเปิดหน้านี้ กรุณาโหลดหน้าเว็บใหม่ก่อนแก้ไขต่อ เพื่อป้องกันข้อมูลทับกัน' }, 409);
    if (!current && ifMatch) return json({ error: 'ข้อมูลส่วนกลางเปลี่ยนแปลงแล้ว กรุณาโหลดหน้าเว็บใหม่' }, 409);
    let write;
    if (current) {
      write = await env.DB.prepare(`UPDATE app_state SET state_json=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=1 AND updated_at=?`).bind(jsonText, current.updated_at).run();
    } else {
      write = await env.DB.prepare(`INSERT OR IGNORE INTO app_state (id,state_json,updated_at) VALUES (1,?,strftime('%Y-%m-%dT%H:%M:%fZ','now'))`).bind(jsonText).run();
    }
    if (!write.meta?.changes) return json({ error: 'มีผู้ใช้อื่นบันทึกข้อมูลพร้อมกัน กรุณาโหลดหน้าเว็บใหม่ก่อนแก้ไขต่อ' }, 409);
    const saved = await env.DB.prepare('SELECT updated_at FROM app_state WHERE id=1').first();
    return json({ ok: true, updatedAt: saved.updated_at, savedBy: auth.user.email }, 200, { 'ETag': etagFor(saved) });
  } catch (error) { return json({ error: 'บันทึกข้อมูลไม่สำเร็จ' }, 500); }
}
