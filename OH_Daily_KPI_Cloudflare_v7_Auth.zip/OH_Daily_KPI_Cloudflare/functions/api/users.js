import { json, requireUser } from '../_lib/auth.js';
export async function onRequestGet({ request, env }) {
  try {
    const auth = await requireUser(request, env, ['Admin']); if (auth.error) return auth.error;
    const result = await env.DB.prepare('SELECT id,email,role,verified,active,created_at FROM users ORDER BY created_at,email').all();
    return json({ users: result.results || [] });
  } catch (e) { return json({ error: 'อ่านรายชื่อผู้ใช้ไม่สำเร็จ' }, 500); }
}
export async function onRequestPatch({ request, env }) {
  try {
    const auth = await requireUser(request, env, ['Admin']); if (auth.error) return auth.error;
    const body = await request.json(), email = String(body.email || '').trim().toLowerCase(), role = String(body.role || '');
    if (!['Admin','Editor','Viewer'].includes(role)) return json({ error: 'สิทธิ์ไม่ถูกต้อง' }, 400);
    if (email === auth.user.email && role !== 'Admin') return json({ error: 'ไม่สามารถลดสิทธิ์ Admin ของบัญชีที่กำลังใช้งานได้' }, 400);
    const result = await env.DB.prepare('UPDATE users SET role=? WHERE email=?').bind(role, email).run();
    if (!result.meta?.changes) return json({ error: 'ไม่พบอีเมลนี้ในระบบ' }, 404);
    return json({ ok: true });
  } catch (e) { return json({ error: 'เปลี่ยนสิทธิ์ผู้ใช้ไม่สำเร็จ' }, 500); }
}
