import { json, randomToken, sha256, hashPassword, cookieHeader } from '../../_lib/auth.js';
export async function onRequestPost({ request, env }) {
  try {
    const body = await request.json(), email = String(body.email || '').trim().toLowerCase(), password = String(body.password || '');
    const user = await env.DB.prepare('SELECT id,email,password_hash,salt,role,verified,active FROM users WHERE email=?').bind(email).first();
    if (!user || !user.active) return json({ error: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' }, 401);
    if (!user.verified) return json({ error: 'กรุณายืนยันอีเมลจากลิงก์ที่ส่งไปก่อนเข้าสู่ระบบ' }, 403);
    const hash = await hashPassword(password, user.salt);
    if (hash !== user.password_hash) return json({ error: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' }, 401);
    const token = randomToken(32), tokenHash = await sha256(token);
    await env.DB.prepare("INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES (?,?,datetime('now','+7 days'),datetime('now'))").bind(tokenHash, user.id).run();
    return json({ ok: true, user: { id: user.id, email: user.email, role: user.role } }, 200, { 'Set-Cookie': cookieHeader(token) });
  } catch (e) { return json({ error: 'เข้าสู่ระบบไม่สำเร็จ', detail: String(e.message || e) }, 500); }
}
