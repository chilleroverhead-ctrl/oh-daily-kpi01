import { json, currentUser } from '../../_lib/auth.js';
export async function onRequestGet({ request, env }) {
  try { const user = await currentUser(request, env); return json({ user: user ? { id: user.id, email: user.email, role: user.role } : null }); }
  catch (e) { return json({ error: 'ตรวจสอบสถานะผู้ใช้ไม่สำเร็จ' }, 500); }
}
