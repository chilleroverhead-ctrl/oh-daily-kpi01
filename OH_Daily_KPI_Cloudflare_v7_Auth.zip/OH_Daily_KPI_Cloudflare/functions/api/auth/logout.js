import { json, sha256, clearCookieHeader } from '../../_lib/auth.js';
export async function onRequestPost({ request, env }) {
  try {
    const cookie = request.headers.get('Cookie') || '', match = cookie.match(/(?:^|;\s*)ohkpi_session=([^;]+)/);
    if (match) await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await sha256(decodeURIComponent(match[1]))).run();
    return json({ ok: true }, 200, { 'Set-Cookie': clearCookieHeader() });
  } catch (e) { return json({ ok: true }, 200, { 'Set-Cookie': clearCookieHeader() }); }
}
