import { json, sha256 } from '../../_lib/auth.js';
export async function onRequestPost({ request, env }) {
  try {
    const token = String((await request.json()).token || '');
    if (!token) return json({ error: 'ไม่พบรหัสยืนยัน' }, 400);
    const hash = await sha256(token);
    const row = await env.DB.prepare("SELECT user_id FROM verification_tokens WHERE token_hash=? AND expires_at > datetime('now')").bind(hash).first();
    if (!row) return json({ error: 'ลิงก์ยืนยันไม่ถูกต้องหรือหมดอายุ กรุณาสมัครใหม่เพื่อรับลิงก์อีกครั้ง' }, 400);
    await env.DB.batch([
      env.DB.prepare('UPDATE users SET verified=1 WHERE id=?').bind(row.user_id),
      env.DB.prepare('DELETE FROM verification_tokens WHERE user_id=?').bind(row.user_id)
    ]);
    return json({ ok: true, message: 'ยืนยันอีเมลสำเร็จแล้ว กรุณาเข้าสู่ระบบ' });
  } catch (e) { return json({ error: 'ยืนยันอีเมลไม่สำเร็จ' }, 500); }
}
