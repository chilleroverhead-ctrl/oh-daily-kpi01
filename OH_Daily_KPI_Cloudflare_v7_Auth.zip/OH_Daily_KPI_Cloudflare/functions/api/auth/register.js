import { json, randomToken, sha256, hashPassword, validCompanyEmail, sendVerificationEmail } from '../../_lib/auth.js';
export async function onRequestPost({ request, env }) {
  try {
    const body = await request.json();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: 'รูปแบบอีเมลไม่ถูกต้อง' }, 400);
    if (password.length < 10) return json({ error: 'รหัสผ่านต้องมีอย่างน้อย 10 ตัวอักษร' }, 400);
    if (!validCompanyEmail(email, env)) return json({ error: 'อีเมลนี้ไม่อยู่ในโดเมนบริษัทที่อนุญาต หรือยังไม่ได้ตั้งค่า COMPANY_EMAIL_DOMAINS' }, 400);
    const existing = await env.DB.prepare('SELECT id, verified FROM users WHERE email=?').bind(email).first();
    if (existing?.verified) return json({ error: 'อีเมลนี้มีบัญชีแล้ว กรุณาเข้าสู่ระบบ' }, 409);
    const id = existing?.id || randomToken(16);
    const salt = randomToken(16);
    const passwordHash = await hashPassword(password, salt);
    const isAdmin = String(env.ADMIN_EMAIL || '').trim().toLowerCase() === email;
    if (existing) {
      await env.DB.prepare('UPDATE users SET password_hash=?, salt=?, role=CASE WHEN ?=1 THEN \'Admin\' ELSE role END, active=1 WHERE id=?').bind(passwordHash, salt, isAdmin ? 1 : 0, id).run();
    } else {
      await env.DB.prepare('INSERT INTO users (id,email,password_hash,salt,role,verified,active,created_at) VALUES (?,?,?,?,?,0,1,datetime(\'now\'))').bind(id, email, passwordHash, salt, isAdmin ? 'Admin' : 'Editor').run();
    }
    await env.DB.prepare('DELETE FROM verification_tokens WHERE user_id=?').bind(id).run();
    const token = randomToken(32), tokenHash = await sha256(token);
    await env.DB.prepare("INSERT INTO verification_tokens (token_hash,user_id,expires_at) VALUES (?,?,datetime('now','+30 minutes'))").bind(tokenHash, id).run();
    await sendVerificationEmail(env, email, token, new URL(request.url).origin);
    return json({ ok: true, message: 'ส่งลิงก์ยืนยันไปยังอีเมลแล้ว กรุณาเปิดอีเมลและกดยืนยันก่อนเข้าสู่ระบบ' });
  } catch (e) {
    return json({ error: 'สมัครบัญชีไม่สำเร็จ', detail: String(e.message || e) }, 500);
  }
}
