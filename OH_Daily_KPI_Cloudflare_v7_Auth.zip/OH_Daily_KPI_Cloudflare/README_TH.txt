OH Daily KPI — ระบบออนไลน์หลายผู้ใช้ (Cloudflare Pages + Pages Functions + D1)

แพ็กเกจนี้ต่อยอดจากไฟล์ V6 โดยเพิ่ม:
- สมัคร/เข้าสู่ระบบด้วยอีเมลและรหัสผ่าน
- จำกัดการสมัครตามโดเมนอีเมลบริษัท และยืนยันอีเมลผ่านลิงก์ก่อนใช้งาน
- บทบาท Admin, Editor, Viewer โดยตรวจสิทธิ์ที่ API ฝั่งเซิร์ฟเวอร์
- Admin จัดการบทบาทผู้ใช้จากปุ่ม “จัดการผู้ใช้”
- ข้อมูล KPI เก็บใน Cloudflare D1 และใช้ร่วมกันทุกเครื่อง
- ป้องกันการบันทึกทับจากการแก้ไขพร้อมกัน ด้วย ETag/version check; หากมีข้อมูลใหม่กว่า ระบบแจ้งให้โหลดหน้าเว็บใหม่
- session cookie แบบ HttpOnly, Secure, SameSite=Lax; password hash PBKDF2-SHA256 (100,000 iterations)
- ส่งออก Excel ต้องเข้าสู่ระบบก่อน

ข้อสำคัญ:
1. ZIP นี้เป็นชุด source code สำหรับ deploy ไม่ใช่เว็บไซต์ออนไลน์ที่ publish แล้ว
2. ต้องมีบัญชี Cloudflare, D1 database และตั้งค่าอีเมลส่งยืนยันก่อนเปิดสมัคร
3. ต้องตั้ง COMPANY_EMAIL_DOMAINS ให้ตรงกับโดเมนบริษัทจริง เช่น company.co.th (ไม่ต้องใส่ @)
4. ตั้ง ADMIN_EMAIL เป็นอีเมลบริษัทของผู้ดูแลระบบคนแรกให้ตรงทุกตัวอักษร
5. ระบบใช้ Resend API ส่งอีเมลยืนยัน ต้องมี Resend account และ verified sender domain พร้อมค่า RESEND_API_KEY และ RESEND_FROM
6. ไม่ควรเปิดใช้งานจริงก่อนทดสอบการสมัคร, ยืนยันอีเมล, บทบาท, การบันทึก, และการส่งออก Excel

A. เตรียม Cloudflare D1
1. เข้า https://dash.cloudflare.com/ แล้วเลือก Workers & Pages > D1 SQL Database
2. สร้างฐานข้อมูลชื่อ oh-daily-kpi-db
3. เปิดฐานข้อมูล > Console แล้วคัดลอกเนื้อหา schema.sql ไปรันทั้งหมด
   - หากมีตาราง app_state จาก V6 อยู่แล้ว ข้อมูลเดิมใน app_state จะไม่ถูกลบ
4. จด Database ID ไว้สำหรับผูก binding

B. เตรียมอีเมลยืนยันผ่าน Resend
1. สร้างบัญชีที่ https://resend.com/
2. เพิ่มและยืนยันโดเมนผู้ส่งตามขั้นตอนของ Resend
3. สร้าง API Key สำหรับส่งอีเมล
4. กำหนด RESEND_FROM เป็นรูปแบบ เช่น OH Daily KPI <noreply@your-company-domain.com>
   ต้องใช้ที่อยู่ผู้ส่งที่ผ่านการยืนยันแล้วใน Resend

C. Deploy Cloudflare Pages
1. แตก ZIP และอัปโหลดเนื้อหาโฟลเดอร์ OH_Daily_KPI_Cloudflare เข้า Git repository
2. ใน Cloudflare > Workers & Pages สร้าง Pages project โดยเชื่อม Git repository
3. Build settings:
   - Framework preset: None
   - Build command: npm install
   - Build output directory: .
   หาก Cloudflare UI แนะนำค่าที่ต่างออกไป ให้ตรวจว่าผลลัพธ์ build มี index.html และโฟลเดอร์ functions อยู่ใน root ของ output
4. ตั้งค่า D1 binding ใน Pages project > Settings > Functions > D1 database bindings:
   - Variable name: DB
   - เลือก database: oh-daily-kpi-db
5. ใน Settings > Variables and Secrets (Production และ Preview หากต้องการใช้ทั้งสองสภาพแวดล้อม) ตั้งค่า:
   - COMPANY_EMAIL_DOMAINS = company.co.th
     ใส่โดเมนจริงของบริษัท; หลายโดเมนคั่นด้วย comma เช่น company.co.th,subsidiary.co.th
   - ADMIN_EMAIL = อีเมลบริษัทของ Admin คนแรก เช่น kpi-admin@company.co.th
   - RESEND_FROM = OH Daily KPI <noreply@your-verified-domain.com>
   - RESEND_API_KEY = ตั้งเป็น Secret ไม่ใช่ plain text variable
6. Save settings แล้ว redeploy project เพื่อให้ Functions รับค่าใหม่

D. เปิดใช้ครั้งแรก
1. เปิด URL pages.dev ของโปรเจกต์
2. เลือก “สมัครบัญชีใหม่” และสมัครด้วยอีเมลที่ตรงกับ COMPANY_EMAIL_DOMAINS
3. ผู้ใช้ Admin คนแรกต้องสมัครด้วยอีเมลที่ตรงกับ ADMIN_EMAIL
4. เปิดอีเมลแล้วกดลิงก์ยืนยัน จากนั้นกลับมาเข้าสู่ระบบ
5. Admin เปิด “จัดการผู้ใช้” เพื่อกำหนดบทบาท:
   - Admin: จัดการสิทธิ์ผู้ใช้และแก้ไขข้อมูล KPI
   - Editor: กรอก/แก้ไข KPI และส่งออกข้อมูล
   - Viewer: ดูกราฟและส่งออกข้อมูล แต่แก้ไข KPI ไม่ได้
6. แชร์ URL เดียวกันให้พนักงานคนอื่นสมัครด้วยอีเมลบริษัท ยืนยันอีเมล แล้ว Admin กำหนดสิทธิ์

E. ย้ายข้อมูลจาก V6
1. ก่อนย้าย ให้สำรองข้อมูลจากเว็บไซต์เดิมด้วยปุ่มส่งออก CSV
2. หลัง deploy และเข้าสู่ระบบด้วย Admin/Editor แล้ว ใช้ปุ่ม “นำเข้า CSV” เพื่อเพิ่มข้อมูลจากไฟล์สำรอง
3. ตรวจกราฟและจำนวนข้อมูลก่อนให้พนักงานใช้งานจริง

การป้องกันข้อมูลและข้อจำกัด
- D1 เป็นฐานข้อมูลออนไลน์ส่วนกลาง ไม่ใช่ไฟล์ SQLite ในคอมพิวเตอร์ของผู้ใช้
- Viewer ถูกป้องกันที่ API ด้วย ไม่ได้อาศัยแค่การซ่อนปุ่มในหน้าเว็บ
- การสมัครต้องใช้โดเมนที่ allowlist และกดยืนยันลิงก์ที่ส่งไปยังอีเมลนั้น
- Session มีอายุ 7 วันและเก็บ token hash ใน D1; รหัสผ่านไม่เก็บเป็นข้อความธรรมดา
- ถ้าผู้ใช้หลายคนเปิดข้อมูลชุดเดียวกันและมีคนบันทึกก่อน ผู้ใช้ที่มีข้อมูลเก่าจะได้รับข้อความเตือนให้โหลดหน้าใหม่ เพื่อป้องกันการบันทึกทับ
- ระบบนี้เก็บข้อมูล KPI ทั้งชุดไว้ใน app_state หนึ่งรายการ เหมาะกับการเริ่มต้นและทีมขนาดเล็ก/กลาง หากต้องการ audit trail รายช่อง, การแก้ไขพร้อมกันแบบละเอียด, หรือประวัติข้อมูลย้อนหลัง ควรพัฒนาฐานข้อมูลแยกตามวัน/KPI เพิ่ม
- ยังไม่ได้ตั้งค่า rate limiting/ล็อกบัญชีเมื่อพยายามเข้าสู่ระบบผิดหลายครั้ง; ควรเพิ่ม Cloudflare Turnstile หรือ rate limiting ก่อนเปิดสาธารณะวงกว้าง
- สำรอง D1 เป็นระยะ และทดสอบการกู้คืนก่อนใช้งานจริง
- หากอีเมลไม่ส่ง ให้ตรวจ Resend sender domain, RESEND_API_KEY, RESEND_FROM และ Cloudflare environment variables

ไฟล์สำคัญ
- index.html: หน้าเว็บและการควบคุมตามบทบาท
- functions/api/auth/register.js: สมัครและส่งอีเมลยืนยัน
- functions/api/auth/verify.js: ยืนยันอีเมล
- functions/api/auth/login.js, me.js, logout.js: session login/logout
- functions/api/users.js: Admin เปลี่ยนบทบาท
- functions/api/state.js: อ่าน/บันทึก KPI พร้อมสิทธิ์และตรวจการบันทึกทับ
- functions/api/export.js: ส่งออก Excel โดยต้องเข้าสู่ระบบ
- functions/_lib/auth.js: ตรวจ session, hash password/token, domain allowlist
- schema.sql: ตาราง D1
- _headers: security headers เบื้องต้น
